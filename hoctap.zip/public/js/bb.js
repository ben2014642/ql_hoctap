function showSuccess(msg) {
    toastr.success(msg,'success');
}

function showError(msg) {
    toastr.error(msg,'error');
}